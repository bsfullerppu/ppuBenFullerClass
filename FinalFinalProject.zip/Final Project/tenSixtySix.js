function normanInvasion() {
  window.location = "willyTheConq.html";
}
function haroldGodwinson() {
  history.back();
}
function siteNotComplete() {
  document.getElementById("siteNotFinished").innerHTML =
    "This site is a work in progress!!!";
}
function annoyingLoop() {
  let i = 10;
  while (i >= 1) {
    alert(
      `This loop serves no purpose, other than counting down to 1, but it is annoying. ${i}`
    );
    i--;
  }
}
function timeMachine() {
  let i;
  for (i = 2022; i >= 2015; i--) {
    if (i > 2015) {
      alert(`Let's go back to 1066! We are now in: ${i}`);
    } else {
      alert(
        "Just kidding, I won't make you wait as I count down to 1066! We are now there. The current year is: 1066"
      );
    }
  }
}
