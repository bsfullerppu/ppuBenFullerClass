function windowOpener() {
  window.open("https://en.wikipedia.org/wiki/Latin_grammar");
}
function windowCloser() {
  window.close();
}
function goBack() {
  history.back();
}
function goBackSpecified() {
  const backNum = document.getElementById("specifyNumber").value;
  history.go(-backNum);
}
function timeoutFunctionTrigger() {
  alert("You have completed the assignment!");
}
function timeoutFunction() {
  setTimeout("timeoutFunctionTrigger()", 5000);
}
