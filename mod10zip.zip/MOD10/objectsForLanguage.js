/*const italian = {
  broadestFamily: "Indo-European",
  mostNarrowFamily: "Italo-Dalmation",
  branchOfIETree: "Romance/Italic",
  numberOfNativeSpeakers: "67 Million",
  countryOfOrigin: "Italy",
  continentOfOrigin: "Europe",
  officialLangaugeIn: "Italy, San Marino, Vatican City, and Switzerland",
  minorityLanguageIn: "Slovenia, Croatia, Bosnia and Herzegovina, and Romania",
  protoLanguage: "Proto-Italic",
  firstProtoLanguage: "Proto-Indo-European",
};*/
function languageFacts(
  broadFam,
  narrowFam,
  ieBranch,
  numSpeakers,
  country,
  continent,
  languageOf,
  minorityIn,
  protoLang,
  origProto
) {
  this.broadestFamily = broadFam;
  this.mostNarrowFamily = narrowFam;
  this.branchOfIETree = ieBranch;
  this.numberOfNativeSpeakers = numSpeakers;
  this.countryOfOrigin = country;
  this.continentOfOrigin = continent;
  this.officialLanguageIn = languageOf;
  this.minorityLanguageIn = minorityIn;
  this.protoLanguage = protoLang;
  this.firstProtoLanguage = origProto;
}
const italianFacts = new languageFacts(
  "Italo-Dalmatian",
  "Romance/Italic",
  "67 million",
  "Italy",
  "Europe",
  "Italy, San Marino, Vatican City, and Switzerland",
  "Slovenia, Croatia, Bosnia and Herzegovina, and Romania",
  "Proto-Italic",
  "Proto-Indo-European"
);
document.write(
  "Italian is an " +
    italianFacts.broadestFamily +
    " language. " +
    italianFacts.broadestFamily +
    " is a language family that encompases many languages from Irish in the west all the way to Hindi in the east. Italian belongs to the " +
    italianFacts.branchOfIETree +
    " branch of the " +
    italianFacts.broadestFamily +
    " family tree. However, Italian itself can be narrowed down to the " +
    italianFacts.mostNarrowFamily +
    " branch of the Italic tree. Italian has " +
    italianFacts.numberOfNativeSpeakers +
    " speakers. Italian, obviously, originated in " +
    italianFacts.countryOfOrigin +
    ". " +
    italianFacts.countryOfOrigin +
    " is a country in " +
    italianFacts.continentOfOrigin +
    ". Italian can be found in " +
    italianFacts.officialLanguageIn +
    " as an official language. However, Italian is a minority language in certain parts of " +
    italianFacts.minorityLanguageIn +
    ". Before evolving from Latin into Italian, there was a language called " +
    italianFacts.protoLanguage +
    " which, in turn, evolved from " +
    italianFacts.firstProtoLanguage +
    "."
);
console.log(
  "Italian is an " +
    italianFacts.broadestFamily +
    " language. " +
    italianFacts.broadestFamily +
    " is a language family that encompases many languages from Irish in the west all the way to Hindi in the east. Italian belongs to the " +
    italianFacts.branchOfIETree +
    " branch of the " +
    italianFacts.broadestFamily +
    " family tree. However, Italian itself can be narrowed down to the " +
    italianFacts.mostNarrowFamily +
    " branch of the Italic tree. Italian has " +
    italianFacts.numberOfNativeSpeakers +
    " speakers. Italian, obviously, originated in " +
    italianFacts.countryOfOrigin +
    ". " +
    italianFacts.countryOfOrigin +
    " is a country in " +
    italianFacts.continentOfOrigin +
    ". Italian can be found in " +
    italianFacts.officialLanguageIn +
    " as an official language. However, Italian is a minority language in certain parts of " +
    italianFacts.minorityLanguageIn +
    ". Before evolving from Latin into Italian, there was a language called " +
    italianFacts.protoLanguage +
    " which, in turn, evolved from " +
    italianFacts.firstProtoLanguage +
    "."
);
