const tvShow = {
  showTitle: "Doctor Who",
  genre: "Sci-Fi",
  firstEpisodeYear: "1963",
  mainCharacter: "The Doctor",
  numberOfSeasons: "39",
  numberOfDoctors: "13",
  firstDoctor: "William Hartnell",
  mostRecentDoctor: "Joadie Whitaker",
  numberOfRelatedMovies: "3",
  originalWriters: "Sydney Newman and Donald Wilson",
};
document.write(
  tvShow.showTitle +
    " is a " +
    tvShow.genre +
    " show. " +
    "It first aired in the year " +
    tvShow.firstEpisodeYear +
    ". " +
    "The main character of the show is a Time Lord who goes by the title " +
    tvShow.mainCharacter +
    "." +
    " So far, the series has had a total of " +
    tvShow.numberOfSeasons +
    " seasons, if you count the classic " +
    tvShow.showTitle +
    " episodes." +
    " Time Lords are an alien species that can regenerate. When they do this, they change in appearance. " +
    "This means that " +
    tvShow.mainCharacter +
    " is played by different actors over the years." +
    " The total number of Doctors has been " +
    tvShow.numberOfDoctors +
    ". However, one may say that there have been a total of 14 Doctors." +
    " The War Doctor was portrayed by John Hurt. However, " +
    tvShow.mostRecentDoctor +
    " is still said to play the 13th (and most recent) Doctor." +
    " The orignal Doctor was played by " +
    tvShow.firstDoctor +
    "." +
    " There have also been " +
    tvShow.numberOfRelatedMovies +
    " " +
    tvShow.showTitle +
    " movies." +
    " The creators of Doctor Who were " +
    tvShow.originalWriters +
    "."
);
